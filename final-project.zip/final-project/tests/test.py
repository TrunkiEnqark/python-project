from controllers import *

tester_manager = TesterManager()
developer_manager = DevManager()

print(developer_manager.search_dev_by_programming_languages(languages=['python']))