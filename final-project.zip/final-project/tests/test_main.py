import time
import sys
import io
import random
import string
from contextlib import redirect_stdout
from unittest.mock import patch
from final_project.main import main, TesterManager, DevManager, developer_manager, tester_manager
from models.developer import Developer
from models.tester import Tester, TesterType
from utils.utils import id_generator

class TestEmployeeManagement:
    def __init__(self):
        self.tester_manager = TesterManager()
        self.developer_manager = DevManager()
        self.test_results = []
        
    def measure_time(self, func, *args):
        """Measure execution time of a function"""
        start_time = time.time()
        result = func(*args)
        end_time = time.time()
        execution_time = end_time - start_time
        return result, execution_time

    def generate_random_name(self):
        """Generate a random name"""
        return ''.join(random.choices(string.ascii_letters, k=10))

    def generate_random_languages(self):
        """Generate a random list of programming languages"""
        languages = ['Python', 'Java', 'C++', 'JavaScript', 'Ruby', 'Go', 'Rust']
        return random.sample(languages, k=random.randint(1, 4))

    def generate_employees(self, num_devs: int = 1000, num_testers: int = 1000):
        """Generate a large number of employees"""
        print(f"\n=== Generating {num_devs} Developers and {num_testers} Testers ===")
        
        # Generate Developers
        start_time = time.time()
        for _ in range(num_devs):
            emp_id = id_generator()
            name = self.generate_random_name()
            base_sal = random.randint(30000, 100000)
            team_name = f"Team{random.randint(1, 100)}"
            languages = self.generate_random_languages()
            exp_year = random.randint(0, 10)
            is_leader = random.random() < 0.1  # 10% chance of being a leader
            if is_leader:
                bonus_rate = random.uniform(0.05, 0.2)
                dev = Developer(name, base_sal, team_name, languages, exp_year, emp_id, is_leader)
                # Note: TeamLeader needs bonus_rate, but we’ll simplify here by setting is_leader
            else:
                dev = Developer(name, base_sal, team_name, languages, exp_year, emp_id)
            self.developer_manager.add_dev(dev)
        
        # Generate Testers
        for _ in range(num_testers):
            emp_id = id_generator()
            name = self.generate_random_name()
            base_sal = random.randint(30000, 100000)
            bonus_rate = random.uniform(0.05, 0.2)
            tester_type = random.choice([TesterType.AM, TesterType.MT])
            tester = Tester(name, base_sal, bonus_rate, tester_type, emp_id)
            self.tester_manager.add_tester(tester)
        
        end_time = time.time()
        print(f"Generated {num_devs + num_testers} employees in {end_time - start_time:.4f} seconds")

    def test_stress_add_employees(self):
        """Stress test adding 10^5 employees"""
        num_employees = 1000
        with patch('final_project.main.developer_manager', self.developer_manager), \
             patch('final_project.main.tester_manager', self.tester_manager):
            start_time = time.time()
            self.generate_employees(num_devs=num_employees // 2, num_testers=num_employees // 2)
            end_time = time.time()
            self.test_results.append({
                'test': 'Stress test add 10^5 employees',
                'success': len(self.developer_manager.developers) + len(self.tester_manager.testers) == num_employees,
                'time': end_time - start_time
            })

    def test_stress_queries(self):
        """Stress test 10^5 queries"""
        print("\n=== Testing 10^5 Queries ===")
        num_queries = 100000
        
        # Ensure we have employees to query
        if not self.developer_manager.developers or not self.tester_manager.testers:
            self.generate_employees()
        
        # Prepare query data
        all_devs = list(self.developer_manager.developers.values())
        all_testers = list(self.tester_manager.testers.values())
        all_employees = all_devs + all_testers
        
        # Randomly select names and languages for queries
        query_names = [random.choice(all_employees).get_name() for _ in range(num_queries // 3)]
        query_languages = [self.generate_random_languages() for _ in range(num_queries // 3)]
        
        with patch('final_project.main.developer_manager', self.developer_manager), \
             patch('final_project.main.tester_manager', self.tester_manager):
            # Measure search by name
            start_time = time.time()
            for name in query_names:
                self.developer_manager.search_dev_by_name(name)
                self.tester_manager.search_tester_by_name(name)
            name_search_time = time.time() - start_time
            
            # Measure search by languages
            start_time = time.time()
            for languages in query_languages:
                self.developer_manager.search_dev_by_programming_languages(languages)
            lang_search_time = time.time() - start_time
            
            total_time = name_search_time + lang_search_time
            self.test_results.append({
                'test': 'Stress test 10^5 queries (name + languages)',
                'success': True,  # Success is assumed if no crashes; adjust if you want specific checks
                'time': total_time
            })
            print(f"Completed {num_queries // 3} name searches in {name_search_time:.4f} seconds")
            print(f"Completed {num_queries // 3} language searches in {lang_search_time:.4f} seconds")
        
    def measure_time(self, func, *args):
        """Measure execution time of a function"""
        start_time = time.time()
        result = func(*args)
        end_time = time.time()
        execution_time = end_time - start_time
        return result, execution_time

    def test_add_employee(self):
        """Test adding employees with various scenarios"""
        print("\n=== Testing Add Employee ===")
        
        with patch('final_project.main.developer_manager', self.developer_manager), \
             patch('final_project.main.tester_manager', self.tester_manager):
            # Test case 1: Add valid developer
            inputs = ['2', 'John Doe', '50000', 'd', 'TeamA', 'Python,Java', '5', 'n', 'b', '7']
            with patch('builtins.input', side_effect=inputs):
                f = io.StringIO()
                with redirect_stdout(f):
                    result, time_taken = self.measure_time(main)
                output = f.getvalue()
                self.test_results.append({
                    'test': 'Add valid developer',
                    'success': 'Success: Added developer' in output,
                    'time': time_taken
                })

            # Test case 2: Add invalid salary
            inputs = ['2', 'Jane Doe', 'invalid', 'd', 'TeamB', 'Python', '3', 'n', 'b', '7']
            with patch('builtins.input', side_effect=inputs):
                f = io.StringIO()
                with redirect_stdout(f):
                    result, time_taken = self.measure_time(main)
                output = f.getvalue()
                self.test_results.append({
                    'test': 'Add developer with invalid salary',
                    'success': 'Error' in output or 'Invalid' in output,
                    'time': time_taken
                })

    def test_update_employee(self):
        """Test updating employees"""
        print("\n=== Testing Update Employee ===")
        
        # First add an employee
        emp_id = id_generator()
        dev = Developer("Test Dev", 60000, "TeamC", ["Python"], 2, emp_id)
        self.developer_manager.add_dev(dev)
        
        # Test case: Update existing employee
        with patch('final_project.main.developer_manager', self.developer_manager), \
             patch('final_project.main.tester_manager', self.tester_manager):
            inputs = ['3', dev.get_id(), 'New Name', '70000', 'Python,JavaScript', '3', 'b', '7']
            with patch('builtins.input', side_effect=inputs):
                f = io.StringIO()
                with redirect_stdout(f):
                    result, time_taken = self.measure_time(main)
                output = f.getvalue()
                self.test_results.append({
                    'test': 'Update existing employee',
                    'success': 'Employee updated successfully' in output,
                    'time': time_taken
                })

    def test_search_employee(self):
        """Test search functionality"""
        print("\n=== Testing Search Employee ===")
        
        # Add a developer
        emp_id = id_generator()
        dev = Developer("Test Dev", 60000, "TeamC", ["Python"], 2, emp_id)
        self.developer_manager.add_dev(dev)
        
        with patch('final_project.main.developer_manager', self.developer_manager), \
             patch('final_project.main.tester_manager', self.tester_manager):
            inputs = ['4', '1', 'Test Dev', 'b', '7']
            with patch('builtins.input', side_effect=inputs):
                f = io.StringIO()
                with redirect_stdout(f):
                    result, time_taken = self.measure_time(main)
                output = f.getvalue()
                self.test_results.append({
                    'test': 'Search by name',
                    'success': 'Found' in output,
                    'time': time_taken
                })

    def test_sort_employee(self):
        """Test sorting functionality"""
        print("\n=== Testing Sort Employee ===")
        
        # Add developers for sorting
        emp_id1 = id_generator()
        dev1 = Developer("Another Dev", 55000, "TeamC", ["Java"], 1, emp_id1)
        self.developer_manager.add_dev(dev1)
        
        emp_id2 = id_generator()
        dev2 = Developer("Test Dev", 60000, "TeamC", ["Python"], 2, emp_id2)
        self.developer_manager.add_dev(dev2)
        
        with patch('final_project.main.developer_manager', self.developer_manager), \
             patch('final_project.main.tester_manager', self.tester_manager):
            inputs = ['6', 's', 'b', '7']
            with patch('builtins.input', side_effect=inputs):
                f = io.StringIO()
                with redirect_stdout(f):
                    result, time_taken = self.measure_time(main)
                output = f.getvalue()
                self.test_results.append({
                    'test': 'Sort by salary',
                    'success': 'Employees sorted by salary' in output,
                    'time': time_taken
                })

    def test_file_storage(self):
        """Test saving to and loading from JSON files"""
        print("\n=== Testing File Storage ===")
        
        # Add a tester
        tester = Tester("Test Tester", 45000, 0.1, TesterType.AM, "T001")
        self.tester_manager.add_tester(tester)
        
        with patch('final_project.main.developer_manager', self.developer_manager), \
             patch('final_project.main.tester_manager', self.tester_manager):
            inputs = ['5', 'b', '7']
            with patch('builtins.input', side_effect=inputs):
                f = io.StringIO()
                with redirect_stdout(f):
                    result, time_taken = self.measure_time(main)
                output = f.getvalue()
                self.test_results.append({
                    'test': 'Save data to files',
                    'success': 'Data stored successfully' in output,
                    'time': time_taken
                })

    def run_all_tests(self):
        """Run all test cases including stress tests"""
        self.test_add_employee()
        self.test_update_employee()
        self.test_search_employee()
        self.test_sort_employee()
        self.test_file_storage()
        self.test_stress_add_employees()
        self.test_stress_queries()
        
        # Print results
        print("\n=== Test Results ===")
        print(f"{'Test Case':<40} {'Status':<10} {'Time (s)':<10}")
        print("-" * 60)
        for result in self.test_results:
            status = "PASS" if result['success'] else "FAIL"
            print(f"{result['test']:<40} {status:<10} {result['time']:.4f}")

if __name__ == '__main__':
    tester = TestEmployeeManagement()
    tester.run_all_tests()