from models.developer import Developer, DevManager
from models.tester import Tester, TesterManager, TesterType

# Khởi tạo DevManager và TesterManager
dev_manager = DevManager()
tester_manager = TesterManager()

# Thêm một developer mới
dev1 = Developer(
    emp_name="Pham Van D",
    base_sal=18000000,
    team_name="Backend Team",
    programming_languages=["Python", "Go"],
    exp_year=5,
    emp_id="D004"
)
dev_manager.add_dev(dev1)

# Thêm một tester mới
tester1 = Tester(
    emp_name="Nguyen Thi E",
    base_sal=15000000,
    bonus_rate=0.2,
    tester_type=TesterType.AT,
    emp_id="T004"
)
tester_manager.add_tester(tester1)

# Hiển thị tất cả developers
print("=== Danh sách Developers ===")
for dev in dev_manager.developers.values():
    print(dev)

# Hiển thị tất cả testers
print("\n=== Danh sách Testers ===")
for tester in tester_manager.testers.values():
    print(tester)

# Tìm developer theo tên
print("\n=== Tìm Developer theo tên: Pham Van D ===")
result = dev_manager.search_dev_by_name("Pham Van D")
for dev in result:
    print(dev)

# Xóa một developer
print("\n=== Xóa Developer có ID: D004 ===")
dev_manager.remove_dev("D004")
print("Danh sách sau khi xóa:")
for dev in dev_manager.developers.values():
    print(dev)

# Xóa một tester
print("\n=== Xóa Tester có ID: T004 ===")
tester_manager.remove_tester("T004")
print("Danh sách sau khi xóa:")
for tester in tester_manager.testers.values():
    print(tester)
